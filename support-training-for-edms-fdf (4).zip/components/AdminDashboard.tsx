import React, { useState } from 'react';
import type { User, Role } from '../types';
import { TrashIcon, EditIcon, UserAddIcon } from './icons';
import ConfirmationModal from './ConfirmationModal';

interface AdminDashboardProps {
  currentUser: User;
  users: User[];
  onSave: (users: User[]) => void;
  onBack: () => void;
  showToast: (text: string, type: 'success' | 'error') => void;
}

const AdminDashboard: React.FC<AdminDashboardProps> = ({ currentUser, users, onSave, onBack, showToast }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<Partial<User> | null>(null);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [userToDelete, setUserToDelete] = useState<User | null>(null);

  const openAddModal = () => {
    setEditingUser({});
    setIsModalOpen(true);
  };

  const openEditModal = (user: User) => {
    setEditingUser({ ...user });
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setEditingUser(null);
    setIsModalOpen(false);
  };

  const handleSaveUser = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingUser || !editingUser.username || !editingUser.role) {
        showToast('Username and role are required.', 'error');
        return;
    }

    if (!editingUser.id && !editingUser.password) {
        showToast('Password is required for new users.', 'error');
        return;
    }
    
    // Check for duplicate username
    const isDuplicate = users.some(u => u.username === editingUser.username && u.id !== editingUser.id);
    if (isDuplicate) {
        showToast('Username already exists.', 'error');
        return;
    }

    let updatedUsers: User[];
    if (editingUser.id) { // Editing existing user
      updatedUsers = users.map(u => u.id === editingUser.id ? { ...u, ...editingUser, password: editingUser.password || u.password } as User : u);
      showToast('User updated successfully.', 'success');
    } else { // Adding new user
      const newUser: User = { ...editingUser, id: Date.now() } as User;
      updatedUsers = [...users, newUser];
      showToast('User added successfully.', 'success');
    }
    onSave(updatedUsers);
    closeModal();
  };

  const promptDeleteUser = (user: User) => {
    if (user.id === currentUser.id) {
        showToast("You cannot delete your own account.", 'error');
        return;
    }
    setUserToDelete(user);
    setIsDeleteModalOpen(true);
  };

  const confirmDeleteUser = () => {
    if (!userToDelete) return;
    const updatedUsers = users.filter(u => u.id !== userToDelete.id);
    onSave(updatedUsers);
    showToast('User deleted successfully.', 'success');
    setUserToDelete(null);
    setIsDeleteModalOpen(false);
  };

  return (
    <>
      <div className="max-w-4xl mx-auto">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-3xl font-bold text-cyan-500 dark:text-cyan-400">User Management</h2>
          <button 
            onClick={onBack} 
            className="bg-gray-200 hover:bg-gray-300 dark:bg-gray-700 dark:hover:bg-gray-600 text-gray-800 dark:text-white font-semibold py-2 px-4 rounded-md transition-colors text-sm flex items-center gap-2"
          >
            &larr; Back to Dashboard
          </button>
        </div>
        
        <div className="bg-yellow-100 border-l-4 border-yellow-500 text-yellow-700 dark:bg-yellow-900/50 dark:border-yellow-700 dark:text-yellow-300 p-4 mb-6" role="alert">
            <p className="font-bold">Security Warning</p>
            <p>This is a demonstration app. User credentials are stored in your browser's local storage and are not secure. Do not use real passwords.</p>
        </div>


        <div className="flex justify-end mb-4">
            <button onClick={openAddModal} className="bg-cyan-600 hover:bg-cyan-700 text-white font-bold py-2 px-4 rounded-md transition-colors flex items-center gap-2">
                <UserAddIcon /> Add New User
            </button>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg overflow-hidden">
          <table className="w-full text-sm text-left">
            <thead className="text-xs text-gray-500 dark:text-gray-400 uppercase bg-gray-100 dark:bg-gray-700">
              <tr>
                <th scope="col" className="px-6 py-3">Username</th>
                <th scope="col" className="px-6 py-3">Role</th>
                <th scope="col" className="px-6 py-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {users.map(user => (
                <tr key={user.id} className="border-b border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600/50">
                  <td className="px-6 py-4 font-medium text-gray-800 dark:text-gray-200">{user.username} {user.id === currentUser.id && '(You)'}</td>
                  <td className="px-6 py-4 text-gray-600 dark:text-gray-300">{user.role}</td>
                  <td className="px-6 py-4 text-right">
                    <button onClick={() => openEditModal(user)} className="text-cyan-600 dark:text-cyan-400 hover:text-cyan-500 dark:hover:text-cyan-300 p-2" title="Edit User"><EditIcon/></button>
                    <button onClick={() => promptDeleteUser(user)} className="text-red-600 dark:text-red-500 hover:text-red-500 dark:hover:text-red-400 p-2" title="Delete User"><TrashIcon/></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add/Edit Modal */}
      {isModalOpen && editingUser && (
        <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4" onClick={closeModal}>
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-2xl p-6 w-full max-w-md" onClick={e => e.stopPropagation()}>
            <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-6">{editingUser.id ? 'Edit User' : 'Add New User'}</h3>
            <form onSubmit={handleSaveUser} className="space-y-4">
                <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Username</label>
                    <input type="text" value={editingUser.username || ''} onChange={e => setEditingUser({...editingUser, username: e.target.value})} className="w-full px-3 py-2 bg-gray-100 dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md focus:ring-cyan-500 focus:border-cyan-500" required />
                </div>
                <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Password</label>
                    <input type="password" placeholder={editingUser.id ? 'Leave blank to keep unchanged' : ''} onChange={e => setEditingUser({...editingUser, password: e.target.value})} className="w-full px-3 py-2 bg-gray-100 dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md focus:ring-cyan-500 focus:border-cyan-500" required={!editingUser.id} />
                </div>
                <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Role</label>
                    <select value={editingUser.role || ''} onChange={e => setEditingUser({...editingUser, role: e.target.value as Role})} className="w-full px-3 py-2 bg-gray-100 dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md focus:ring-cyan-500 focus:border-cyan-500" required>
                        <option value="" disabled>Select a role</option>
                        {Object.values('Admin' as Role).includes(currentUser.role) && <option value="Admin">Admin</option>}
                        <option value="Examiner">Examiner</option>
                        <option value="Trainee">Trainee</option>
                    </select>
                </div>
                <div className="flex justify-end gap-3 pt-4">
                    <button type="button" onClick={closeModal} className="bg-gray-200 hover:bg-gray-300 dark:bg-gray-600 dark:hover:bg-gray-500 text-gray-800 dark:text-white font-semibold py-2 px-4 rounded-md">Cancel</button>
                    <button type="submit" className="bg-cyan-600 hover:bg-cyan-700 text-white font-bold py-2 px-4 rounded-md">Save</button>
                </div>
            </form>
          </div>
        </div>
      )}

      <ConfirmationModal
        isOpen={isDeleteModalOpen}
        onClose={() => setIsDeleteModalOpen(false)}
        onConfirm={confirmDeleteUser}
        title="Delete User?"
        message={`Are you sure you want to delete the user "${userToDelete?.username}"? This action cannot be undone.`}
      />
    </>
  );
};

export default AdminDashboard;