import React, { useState, useEffect, useCallback } from 'react';
import type { TrainingImage, UserResult } from '../types';
import Timer from './Timer';
import ConfirmationModal from './ConfirmationModal';

interface TrainingScreenProps {
  trainingData: TrainingImage[];
  onComplete: (results: UserResult[]) => void;
  onQuit: () => void;
}

const TrainingScreen: React.FC<TrainingScreenProps> = ({ trainingData, onComplete, onQuit }) => {
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [userInputs, setUserInputs] = useState<string[]>([]);
  const [results, setResults] = useState<UserResult[]>([]);
  const [startTime, setStartTime] = useState<number>(Date.now());
  const [isLoading, setIsLoading] = useState(true);
  const [isQuitModalOpen, setIsQuitModalOpen] = useState(false);

  const currentImage = trainingData[currentImageIndex];

  useEffect(() => {
    if (currentImage) {
      setUserInputs(new Array(currentImage.items.length).fill(''));
      setStartTime(Date.now());
      setIsLoading(true);
    } else {
        // Handle case where training data might be empty
        onQuit();
    }
  }, [currentImageIndex, currentImage, onQuit]);

  const handleInputChange = (index: number, value: string) => {
    const newInputs = [...userInputs];
    newInputs[index] = value;
    setUserInputs(newInputs);
  };

  const handleSubmit = useCallback(() => {
    const timeTaken = Math.round((Date.now() - startTime) / 1000);
    const newResult: UserResult = {
      imageId: currentImage.id,
      timeTaken,
      items: currentImage.items.map((item, index) => ({
        prompt: item.prompt,
        userInput: userInputs[index] || '',
        isCorrect: (userInputs[index] || '').trim().toLowerCase() === item.correctAnswer.trim().toLowerCase(),
      })),
    };

    const updatedResults = [...results, newResult];
    setResults(updatedResults);

    if (currentImageIndex < trainingData.length - 1) {
      setCurrentImageIndex(currentImageIndex + 1);
    } else {
      onComplete(updatedResults);
    }
  }, [startTime, currentImage, userInputs, results, currentImageIndex, trainingData.length, onComplete]);

  const handleQuit = () => {
    setIsQuitModalOpen(true);
  };

  const confirmQuit = () => {
    setIsQuitModalOpen(false);
    onQuit();
  };

  if (!currentImage) {
    return <div className="text-center">No training data available.</div>
  }

  return (
    <>
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
        {/* Image Panel */}
        <div className="lg:col-span-3 bg-white dark:bg-gray-800 p-4 rounded-lg shadow-2xl flex flex-col items-center justify-center min-h-[400px]">
          <div className="w-full text-center mb-2">
              <span className="text-gray-500 dark:text-gray-400 text-sm">Image {currentImageIndex + 1} of {trainingData.length}</span>
          </div>
          <div className="relative w-full h-full max-h-[80vh] flex items-center justify-center">
              {isLoading && <div className="text-gray-500 dark:text-gray-400">Loading image...</div>}
              <img
                  src={currentImage.imageUrl}
                  alt="Invoice"
                  className={`object-contain w-full h-full transition-opacity duration-500 ${isLoading ? 'opacity-0' : 'opacity-100'}`}
                  onLoad={() => setIsLoading(false)}
              />
          </div>
        </div>

        {/* Data Entry Panel */}
        <div className="lg:col-span-2 bg-white dark:bg-gray-800 p-6 rounded-lg shadow-2xl flex flex-col">
          <div className="flex justify-between items-center mb-6">
            <h3 className="text-xl font-bold text-gray-900 dark:text-white">Data Entry</h3>
            <Timer startTime={startTime} />
          </div>
          <div className="space-y-4 overflow-y-auto flex-grow pr-2">
            {currentImage.items.map((item, index) => (
              <div key={`${currentImage.id}-${index}`}>
                <label className="block text-sm font-medium text-cyan-600 dark:text-cyan-400 mb-1">
                  Entry for: {item.prompt}
                </label>
                <input
                  type="text"
                  autoComplete="off"
                  value={userInputs[index]}
                  onChange={(e) => handleInputChange(index, e.target.value)}
                  className="w-full px-3 py-2 bg-gray-100 dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md focus:ring-cyan-500 focus:border-cyan-500 transition"
                />
              </div>
            ))}
          </div>
          <div className="mt-6 space-y-3">
            <button
              onClick={handleSubmit}
              className="w-full bg-cyan-600 hover:bg-cyan-700 text-white font-bold py-3 px-4 rounded-md transition-colors"
            >
              {currentImageIndex < trainingData.length - 1 ? 'Confirm & Next Image' : 'Finish Training'}
            </button>
            <button
              onClick={handleQuit}
              className="w-full bg-gray-500 hover:bg-gray-600 dark:bg-gray-600 dark:hover:bg-gray-500 text-white font-bold py-2 px-4 rounded-md transition-colors text-sm"
            >
              Quit Training
            </button>
          </div>
        </div>
      </div>
      <ConfirmationModal
        isOpen={isQuitModalOpen}
        onClose={() => setIsQuitModalOpen(false)}
        onConfirm={confirmQuit}
        title="Quit Training?"
        message="Are you sure you want to quit? Your progress will be lost and you will return to the dashboard."
      />
    </>
  );
};

export default TrainingScreen;