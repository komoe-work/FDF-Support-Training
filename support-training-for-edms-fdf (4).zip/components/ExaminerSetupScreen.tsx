import React, { useState, useEffect } from 'react';
import type { TrainingImage, TrainingItem } from '../types';
import { TrashIcon, ZoomInIcon, EditIcon, SaveIcon } from './icons';
import ImageModal from './ImageModal';
import ConfirmationModal from './ConfirmationModal';

interface ExaminerSetupScreenProps {
  initialData: TrainingImage[];
  onSave: (data: TrainingImage[]) => void;
  onBack: () => void;
  showToast: (text: string, type: 'success' | 'error') => void;
}

interface StagedImage {
    tempId: number;
    imageDataUrl: string;
    items: Partial<TrainingItem>[];
}

const ExaminerSetupScreen: React.FC<ExaminerSetupScreenProps> = ({ initialData, onSave, onBack, showToast }) => {
  const [trainingData, setTrainingData] = useState<TrainingImage[]>(initialData);
  const [stagedImages, setStagedImages] = useState<StagedImage[]>([]);
  const [modalImageUrl, setModalImageUrl] = useState<string | null>(null);

  const [editingImageId, setEditingImageId] = useState<number | null>(null);
  const [editedItems, setEditedItems] = useState<Partial<TrainingItem>[]>([]);
  
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [imageToDelete, setImageToDelete] = useState<number | null>(null);

  // Sync local state with props to ensure UI consistency after saves/deletes
  useEffect(() => {
    setTrainingData(initialData);
  }, [initialData]);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
        const files = Array.from(e.target.files);

        const readFileAsDataURL = (file: File): Promise<string> => {
            return new Promise((resolve, reject) => {
                const reader = new FileReader();
                reader.onload = () => resolve(reader.result as string);
                reader.onerror = reject;
                reader.readAsDataURL(file);
            });
        };

        try {
            const dataUrls = await Promise.all(files.map(readFileAsDataURL));
            const newStaged: StagedImage[] = dataUrls.map((url, index) => ({
                tempId: Date.now() + index,
                imageDataUrl: url,
                items: [{ prompt: '', correctAnswer: '' }],
            }));
            setStagedImages(prev => [...prev, ...newStaged]);
        } catch (error) {
            console.error("Error reading files:", error);
            showToast("There was an error processing some of the images.", 'error');
        }
        
        e.target.value = ''; // Reset file input to allow re-uploading the same files
    }
  };
  
  const handleStagedItemChange = (tempId: number, index: number, field: keyof TrainingItem, value: string) => {
    setStagedImages(currentStaged => 
      currentStaged.map(image => {
        if (image.tempId === tempId) {
          const updatedItems = [...image.items];
          updatedItems[index] = { ...updatedItems[index], [field]: value };
          return { ...image, items: updatedItems };
        }
        return image;
      })
    );
  };

  const handleAddStagedItemField = (tempId: number) => {
    setStagedImages(currentStaged =>
      currentStaged.map(image => {
        if (image.tempId === tempId) {
          return { ...image, items: [...image.items, { prompt: '', correctAnswer: '' }] };
        }
        return image;
      })
    );
  };

  const handleRemoveStagedItemField = (tempId: number, index: number) => {
    setStagedImages(currentStaged =>
        currentStaged.map(image => {
            if (image.tempId === tempId && image.items.length > 1) {
                const updatedItems = image.items.filter((_, i) => i !== index);
                return { ...image, items: updatedItems };
            }
            return image;
        })
    );
  };

  const handleRemoveStagedImage = (tempId: number) => {
    setStagedImages(currentStaged => currentStaged.filter(image => image.tempId !== tempId));
  };
  
  const handleSaveAllStagedImages = () => {
    if (stagedImages.length === 0) {
        showToast("There are no images in the staging area to save.", 'error');
        return;
    }
    
    // Validation: Check for any staged image that has an item with one field filled and the other empty.
    const hasIncompleteEntries = stagedImages.some(image => 
        image.items.some(item => {
            const promptExists = item.prompt && item.prompt.trim() !== '';
            const answerExists = item.correctAnswer && item.correctAnswer.trim() !== '';
            // An entry is incomplete if one field is filled but the other is not.
            return (promptExists && !answerExists) || (!promptExists && answerExists);
        })
    );

    if (hasIncompleteEntries) {
        showToast('Incomplete entries found. Please fill in both prompt and answer for every entry.', 'error');
        return; // Stop the save process, leaving the staged images for the user to correct.
    }
    
    // Filter out images that have no valid entries (i.e., all rows are completely blank).
    const imagesToSave = stagedImages
        .map(stagedImage => {
            const validItems = stagedImage.items
                .filter(item => item.prompt && item.prompt.trim() !== '' && item.correctAnswer && item.correctAnswer.trim() !== '')
                .map(item => item as TrainingItem);
            
            if (validItems.length === 0) return null;

            return {
                id: stagedImage.tempId,
                imageUrl: stagedImage.imageDataUrl,
                items: validItems,
            };
        })
        .filter(Boolean) as TrainingImage[];

    if (imagesToSave.length === 0) {
        // This case will be hit if all staged images have only empty rows.
        showToast('Configure at least one valid prompt and answer before saving.', 'error');
        return;
    }
    
    const updatedData = [...trainingData, ...imagesToSave];
    onSave(updatedData);
    setStagedImages([]); // Clear staging area on success
    showToast(`${imagesToSave.length} image(s) saved successfully!`, 'success');
  };

  const promptDeleteImage = (id: number) => {
    setImageToDelete(id);
    setIsDeleteModalOpen(true);
  };

  const confirmDeleteImage = () => {
    if (imageToDelete === null) return;

    const updatedData = trainingData.filter(image => image.id !== imageToDelete);
    onSave(updatedData);
    showToast('Image deleted successfully.', 'success');
    
    // Reset state
    setIsDeleteModalOpen(false);
    setImageToDelete(null);
  };


  const handleEditClick = (image: TrainingImage) => {
    setEditingImageId(image.id);
    // Deep copy items to avoid direct mutation
    setEditedItems(JSON.parse(JSON.stringify(image.items)));
  };

  const handleCancelEdit = () => {
    setEditingImageId(null);
    setEditedItems([]);
  };
  
  const handleSaveEdit = () => {
    if (!editingImageId) return;

    // Validation: Check for items with one field filled but the other empty.
    const hasIncompleteEntries = editedItems.some(item => {
        const promptExists = item.prompt && item.prompt.trim() !== '';
        const answerExists = item.correctAnswer && item.correctAnswer.trim() !== '';
        // An entry is incomplete if one field is filled but the other is not.
        return (promptExists && !answerExists) || (!promptExists && answerExists);
    });

    if (hasIncompleteEntries) {
        showToast('Incomplete entries found. Please fill in both prompt and answer for every entry.', 'error');
        return; // Stop the save process, leaving the items for the user to correct.
    }

    // Filter out completely blank rows before saving.
    const validItems = editedItems
      .filter(item => item.prompt && item.prompt.trim() !== '' && item.correctAnswer && item.correctAnswer.trim() !== '')
      .map(item => item as TrainingItem);
    
    if (validItems.length === 0) {
        showToast('An image must have at least one valid prompt and answer.', 'error');
        return;
    }

    const updatedData = trainingData.map(image => 
      image.id === editingImageId ? { ...image, items: validItems } : image
    );

    onSave(updatedData);
    showToast('Image updated successfully!', 'success');
    handleCancelEdit();
  };

  const handleEditedItemChange = (index: number, field: keyof TrainingItem, value: string) => {
    const newItems = [...editedItems];
    newItems[index] = { ...newItems[index], [field]: value };
    setEditedItems(newItems);
  };
  
  const handleAddEditedItemField = () => {
    setEditedItems([...editedItems, { prompt: '', correctAnswer: '' }]);
  };

  const handleRemoveEditedItemField = (index: number) => {
    if (editedItems.length > 1) {
        setEditedItems(editedItems.filter((_, i) => i !== index));
    }
  };

  return (
    <>
      <div className="max-w-6xl mx-auto">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-3xl font-bold text-cyan-500 dark:text-cyan-400">Training Setup</h2>
          <button 
            onClick={onBack} 
            className="bg-gray-200 hover:bg-gray-300 dark:bg-gray-700 dark:hover:bg-gray-600 text-gray-800 dark:text-white font-semibold py-2 px-4 rounded-md transition-colors text-sm flex items-center gap-2"
          >
            &larr; Back to Dashboard
          </button>
        </div>

        {/* --- Staging Area --- */}
        <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-lg mb-8">
          <h3 className="text-xl font-bold mb-4 text-gray-900 dark:text-white">Add New Training Images</h3>
          
          <div>
              <label htmlFor="image-upload" className="block text-sm font-medium text-gray-600 dark:text-gray-300 mb-2">Upload Invoice/Bank Images (you can select multiple files)</label>
              <input id="image-upload" type="file" accept="image/*" multiple onChange={handleFileChange} className="block w-full text-sm text-gray-500 dark:text-gray-400 file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-semibold file:bg-cyan-600 file:text-white hover:file:bg-cyan-700"/>
          </div>
          
          {stagedImages.length > 0 && (
              <div className="mt-6 space-y-6">
                  <h4 className="text-lg font-semibold text-gray-800 dark:text-gray-200">Staged Images</h4>
                  {stagedImages.map(image => (
                      <div key={image.tempId} className="bg-gray-50 dark:bg-gray-700/50 p-4 rounded-lg border border-gray-200 dark:border-gray-600 relative">
                          <button onClick={() => handleRemoveStagedImage(image.tempId)} className="absolute top-2 right-2 text-gray-500 dark:text-gray-400 hover:text-gray-800 dark:hover:text-white transition-colors z-10">
                              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
                          </button>
                          <div className="grid md:grid-cols-2 gap-6">
                              <div className="flex items-center justify-center bg-black/10 dark:bg-black/20 rounded-lg group relative cursor-pointer" onClick={() => setModalImageUrl(image.imageDataUrl)}>
                                  <img src={image.imageDataUrl} alt="Preview" className="rounded-lg max-h-80 w-auto object-contain" />
                                  <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
                                    <span className="text-white"><ZoomInIcon/></span>
                                  </div>
                              </div>
                              <div>
                                  <label className="block text-sm font-medium text-gray-600 dark:text-gray-300 mb-2">Enter Prompts and Answers</label>
                                  <div className="space-y-3 max-h-72 overflow-y-auto pr-2">
                                      {image.items.map((item, index) => (
                                          <div key={index} className="flex items-center gap-2">
                                              <input type="text" placeholder="Prompt (e.g., 243,776)" value={item.prompt || ''} onChange={(e) => handleStagedItemChange(image.tempId, index, 'prompt', e.target.value)} className="w-full px-3 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md focus:ring-cyan-500 focus:border-cyan-500 transition text-sm"/>
                                              <input type="text" placeholder="Correct Answer" value={item.correctAnswer || ''} onChange={(e) => handleStagedItemChange(image.tempId, index, 'correctAnswer', e.target.value)} className="w-full px-3 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md focus:ring-cyan-500 focus:border-cyan-500 transition text-sm"/>
                                              <button onClick={() => handleRemoveStagedItemField(image.tempId, index)} className="text-red-400 hover:text-red-300 p-1 rounded-full disabled:opacity-50" disabled={image.items.length <= 1}>
                                                  <TrashIcon/>
                                              </button>
                                          </div>
                                      ))}
                                  </div>
                                  <button onClick={() => handleAddStagedItemField(image.tempId)} className="mt-3 text-sm text-cyan-600 dark:text-cyan-400 hover:text-cyan-500 dark:hover:text-cyan-300">+ Add Another Entry</button>
                              </div>
                          </div>
                      </div>
                  ))}
                  <div className="mt-6 text-right">
                      <button onClick={handleSaveAllStagedImages} className="bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-6 rounded-md transition-colors">
                          Save All Staged Images to Training Set
                      </button>
                  </div>
              </div>
          )}
        </div>
        
        {/* --- Current Training Set --- */}
        <div>
          <h3 className="text-xl font-bold mb-4 text-gray-900 dark:text-white">Current Training Set ({trainingData.length} images)</h3>
          <div className="space-y-4">
              {trainingData.length > 0 ? trainingData.map(image => (
                  <div key={image.id} className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow-md">
                    {editingImageId === image.id ? (
                        /* --- EDITING VIEW --- */
                        <div>
                            <div className="grid md:grid-cols-2 gap-6">
                                <div 
                                  className="flex items-center justify-center bg-black/10 dark:bg-black/20 rounded-lg group relative cursor-pointer"
                                  onClick={() => setModalImageUrl(image.imageUrl)}
                                >
                                    <img src={image.imageUrl} alt="Preview" className="rounded-lg max-h-80 w-auto object-contain" />
                                    <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
                                      <span className="text-white"><ZoomInIcon/></span>
                                    </div>
                                </div>
                                <div>
                                    <label className="block text-sm font-medium text-gray-600 dark:text-gray-300 mb-2">Edit Prompts and Answers</label>
                                    <div className="space-y-3 max-h-72 overflow-y-auto pr-2">
                                        {editedItems.map((item, index) => (
                                            <div key={index} className="flex items-center gap-2">
                                                <input type="text" placeholder="Prompt" value={item.prompt || ''} onChange={(e) => handleEditedItemChange(index, 'prompt', e.target.value)} className="w-full px-3 py-2 bg-gray-100 dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md focus:ring-cyan-500 focus:border-cyan-500 transition text-sm"/>
                                                <input type="text" placeholder="Correct Answer" value={item.correctAnswer || ''} onChange={(e) => handleEditedItemChange(index, 'correctAnswer', e.target.value)} className="w-full px-3 py-2 bg-gray-100 dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md focus:ring-cyan-500 focus:border-cyan-500 transition text-sm"/>
                                                <button onClick={() => handleRemoveEditedItemField(index)} className="text-red-400 hover:text-red-300 p-1 rounded-full disabled:opacity-50" disabled={editedItems.length <= 1}>
                                                    <TrashIcon/>
                                                </button>
                                            </div>
                                        ))}
                                    </div>
                                    <button onClick={handleAddEditedItemField} className="mt-3 text-sm text-cyan-600 dark:text-cyan-400 hover:text-cyan-500 dark:hover:text-cyan-300">+ Add Another Entry</button>
                                </div>
                            </div>
                            <div className="flex justify-end gap-3 mt-4">
                                <button onClick={handleCancelEdit} className="text-gray-500 dark:text-gray-400 hover:text-gray-800 dark:hover:text-white font-semibold py-2 px-4 rounded-md transition-colors text-sm">Cancel</button>
                                <button onClick={handleSaveEdit} className="bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-4 rounded-md transition-colors text-sm flex items-center gap-2">
                                    <SaveIcon /> Save Changes
                                </button>
                            </div>
                        </div>
                    ) : (
                        /* --- DISPLAY VIEW --- */
                        <div className="flex items-start gap-4">
                            <div className="relative group cursor-pointer" onClick={() => setModalImageUrl(image.imageUrl)}>
                                <img src={image.imageUrl} alt={`Training image ${image.id}`} className="w-40 h-auto object-cover rounded"/>
                                <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity rounded">
                                    <span className="text-white"><ZoomInIcon/></span>
                                </div>
                            </div>
                            <div className="flex-grow">
                                <ul className="text-sm list-disc list-inside">
                                    {image.items.map((item, index) => (
                                        <li key={index} className="text-gray-600 dark:text-gray-300"><strong className="text-cyan-600 dark:text-cyan-400">{item.prompt}:</strong> {item.correctAnswer}</li>
                                    ))}
                                </ul>
                            </div>
                            <div className="flex flex-col gap-2">
                                <button 
                                  onClick={() => handleEditClick(image)} 
                                  className="text-cyan-500 hover:text-cyan-400 dark:text-cyan-400 dark:hover:text-cyan-300 p-2 rounded-full transition-colors"
                                  title="Edit Image"
                                >
                                    <EditIcon />
                                </button>
                                <button 
                                  onClick={() => promptDeleteImage(image.id)} 
                                  className="text-red-500 hover:text-red-400 p-2 rounded-full transition-colors"
                                  title="Delete Image"
                                >
                                    <TrashIcon />
                                </button>
                            </div>
                        </div>
                    )}
                  </div>
              )) : <p className="text-gray-500 text-center py-4">No training images have been set up yet. Add one above to get started.</p>}
          </div>
        </div>

        <div className="mt-8 border-t border-gray-200 dark:border-gray-700 pt-6 flex justify-end">
            <button 
                onClick={onBack} 
                className="bg-gray-200 hover:bg-gray-300 dark:bg-gray-700 dark:hover:bg-gray-600 text-gray-800 dark:text-white font-semibold py-2 px-4 rounded-md transition-colors text-sm flex items-center gap-2"
            >
                &larr; Back to Dashboard
            </button>
        </div>
      </div>
      {modalImageUrl && <ImageModal imageUrl={modalImageUrl} onClose={() => setModalImageUrl(null)} />}
      <ConfirmationModal
        isOpen={isDeleteModalOpen}
        onClose={() => setIsDeleteModalOpen(false)}
        onConfirm={confirmDeleteImage}
        title="Delete Training Image?"
        message="Are you sure you want to delete this image and its associated data? This action is permanent."
      />
    </>
  );
};

export default ExaminerSetupScreen;