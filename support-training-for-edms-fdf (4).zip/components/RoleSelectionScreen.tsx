import React from 'react';

interface RoleSelectionScreenProps {
  onSelect: (view: 'trainee' | 'examiner') => void;
}

const RoleSelectionScreen: React.FC<RoleSelectionScreenProps> = ({ onSelect }) => {
  return (
    <div className="flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full space-y-8 bg-gray-800 p-10 rounded-xl shadow-lg text-center">
        <h2 className="text-3xl font-extrabold text-white">
          Select Your Role
        </h2>
        <div className="mt-8 space-y-4">
          <button
            onClick={() => onSelect('trainee')}
            className="w-full bg-cyan-600 hover:bg-cyan-700 text-white font-bold py-3 px-4 rounded-md transition-colors"
          >
            Start as Trainee
          </button>
          <button
            onClick={() => onSelect('examiner')}
            className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3 px-4 rounded-md transition-colors"
          >
            Setup as Examiner
          </button>
        </div>
      </div>
    </div>
  );
};

export default RoleSelectionScreen;
