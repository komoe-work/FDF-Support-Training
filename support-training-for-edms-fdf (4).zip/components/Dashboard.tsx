import React, { useRef, useState } from 'react';
import { User, Role, View } from '../types';
import ConfirmationModal from './ConfirmationModal';

interface DashboardProps {
  user: User;
  setView: (view: View) => void;
  onExportData: () => void;
  onImportData: (jsonString: string) => void;
}

const Dashboard: React.FC<DashboardProps> = ({ user, setView, onExportData, onImportData }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);
  const [fileContent, setFileContent] = useState<string | null>(null);

  const getGreeting = () => {
    const hours = new Date().getHours();
    if (hours < 12) return 'Good morning';
    if (hours < 18) return 'Good afternoon';
    return 'Good evening';
  };

  const handleImportClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileSelected = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      setFileContent(content);
      setIsImportModalOpen(true);
    };
    reader.onerror = () => {
      console.error("Error reading file");
      // An error toast would be shown by the main import handler in App.tsx if parsing fails.
    };
    reader.readAsText(file);

    // Reset input value to allow selecting the same file again
    e.target.value = '';
  };

  const confirmImport = () => {
    if (fileContent) {
      onImportData(fileContent);
    }
    setIsImportModalOpen(false);
    setFileContent(null);
  };

  return (
    <>
      <div className="flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-xl w-full space-y-8 bg-white dark:bg-gray-800 p-10 rounded-xl shadow-lg text-center">
          <div>
            <h2 className="text-3xl font-extrabold text-gray-900 dark:text-white">
              {getGreeting()}, <span className="text-cyan-500 dark:text-cyan-400">{user.username}</span>!
            </h2>
            <p className="mt-2 text-gray-500 dark:text-gray-400">What would you like to do today?</p>
          </div>

          <div className="mt-8 space-y-4">
            {user.role === Role.Trainee && (
              <button
                onClick={() => setView(View.Training)}
                className="w-full bg-cyan-600 hover:bg-cyan-700 text-white font-bold py-4 px-4 rounded-md transition-colors text-lg"
              >
                Start Training Session
              </button>
            )}

            {(user.role === Role.Admin || user.role === Role.Examiner) && (
              <button
                onClick={() => setView(View.ExaminerSetup)}
                className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-4 px-4 rounded-md transition-colors text-lg"
              >
                Setup Training Content
              </button>
            )}

            {user.role === Role.Admin && (
              <button
                onClick={() => setView(View.AdminDashboard)}
                className="w-full bg-gray-600 hover:bg-gray-700 dark:bg-gray-600 dark:hover:bg-gray-500 text-white font-bold py-4 px-4 rounded-md transition-colors text-lg"
              >
                Manage Users
              </button>
            )}
          </div>

          {(user.role === Role.Admin || user.role === Role.Examiner) && (
            <div className="mt-8 pt-6 border-t border-gray-200 dark:border-gray-700">
              <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-4">Data Management</h3>
              <div className="flex flex-col sm:flex-row gap-4">
                <button
                  onClick={onExportData}
                  className="flex-1 bg-green-600 hover:bg-green-700 text-white font-bold py-3 px-4 rounded-md transition-colors"
                >
                  Export All Data
                </button>
                <button
                  onClick={handleImportClick}
                  className="flex-1 bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-4 rounded-md transition-colors"
                >
                  Import All Data
                </button>
              </div>
              <p className="text-xs text-gray-500 dark:text-gray-400 mt-3 text-left">
                Export creates a backup JSON file of all users, content, and history. Import restores the application from a backup file, overwriting all existing data.
              </p>
            </div>
          )}
        </div>
      </div>

      <input
        type="file"
        ref={fileInputRef}
        onChange={handleFileSelected}
        accept=".json,application/json"
        className="hidden"
        aria-hidden="true"
      />

      <ConfirmationModal
        isOpen={isImportModalOpen}
        onClose={() => setIsImportModalOpen(false)}
        onConfirm={confirmImport}
        title="Import Data & Overwrite?"
        message="This will replace all current users, training data, and history with the content from the backup file. This action cannot be undone. Are you sure?"
        variant="primary"
        confirmText="Yes, Import & Overwrite"
      />
    </>
  );
};

export default Dashboard;
