import React from 'react';
import type { UserResult, TrainingImage, TrainingAttempt } from '../types';
import { CheckIcon, XIcon, DownloadIcon } from './icons';

interface ResultsScreenProps {
  username: string;
  results: UserResult[];
  trainingData: TrainingImage[];
  onRestart: () => void;
  userAttempts: TrainingAttempt[];
}

const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}m ${secs}s`;
};

// --- Export Helper Functions ---

const downloadFile = (content: string, filename: string, mimeType: string) => {
    const blob = new Blob([content], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
};

const generateHTMLReport = (username: string, results: UserResult[], trainingData: TrainingImage[], attemptNumber: number) => {
    const totalItems = results.reduce((sum, result) => sum + result.items.length, 0);
    const correctItems = results.reduce((sum, result) => sum + result.items.filter(item => item.isCorrect).length, 0);
    const totalTime = results.reduce((sum, result) => sum + result.timeTaken, 0);
    const accuracy = totalItems > 0 ? ((correctItems / totalItems) * 100).toFixed(1) : '0.0';

    const resultsHtml = results.map((result, index) => {
        const originalImage = trainingData.find(img => img.id === result.imageId);
        const correctInImage = result.items.filter(i => i.isCorrect).length;
        const totalInImage = result.items.length;
        
        const itemsHtml = result.items.map(item => {
            const correctAnswer = originalImage?.items.find(i => i.prompt === item.prompt)?.correctAnswer || 'N/A';
            return `
                <tr>
                    <td>${item.prompt}</td>
                    <td class="${!item.isCorrect ? 'incorrect' : ''}">${item.userInput || '<em>No input</em>'}</td>
                    <td>${correctAnswer}</td>
                    <td class="result-cell">${item.isCorrect ? '<span class="correct-icon">✔</span>' : '<span class="incorrect-icon">✖</span>'}</td>
                </tr>
            `;
        }).join('');

        return `
            <div class="card">
                <div class="card-header">
                    <h2>Image ${index + 1} Review</h2>
                    <div class="stats">
                        <p><strong>${correctInImage} / ${totalInImage}</strong> Correct</p>
                        <p>Time: <strong>${formatTime(result.timeTaken)}</strong></p>
                    </div>
                </div>
                <table>
                    <thead>
                        <tr>
                            <th>Prompt Value</th>
                            <th>Your Input</th>
                            <th>Correct Answer</th>
                            <th>Result</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${itemsHtml}
                    </tbody>
                </table>
            </div>
        `;
    }).join('');

    return `
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Training Results for ${username}</title>
            <style>
                body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; background-color: #f4f7f6; color: #333; margin: 0; padding: 20px; transition: background-color 0.3s, color 0.3s; }
                .container { max-width: 900px; margin: auto; background: #fff; border-radius: 8px; box-shadow: 0 4px 12px rgba(0,0,0,0.1); }
                header { background-color: #083344; color: #fff; padding: 20px 30px; border-top-left-radius: 8px; border-top-right-radius: 8px; }
                header h1 { margin: 0; font-size: 24px; }
                header p { margin: 5px 0 0; color: #a5f3fc; }
                .summary { display: grid; grid-template-columns: repeat(auto-fit, minmax(120px, 1fr)); gap: 20px; padding: 30px; border-bottom: 1px solid #eee; }
                .summary-item { text-align: center; background-color: #f8f9fa; padding: 15px; border-radius: 6px; }
                .summary-item .label { font-size: 14px; color: #666; }
                .summary-item .value { font-size: 28px; font-weight: bold; color: #0e7490; }
                .content { padding: 30px; }
                .card { margin-bottom: 20px; border: 1px solid #ddd; border-radius: 6px; overflow: hidden; }
                .card-header { display: flex; justify-content: space-between; align-items: center; background-color: #f8f9fa; padding: 10px 15px; border-bottom: 1px solid #ddd; }
                .card-header h2 { font-size: 18px; margin: 0; }
                .card-header .stats { text-align: right; font-size: 14px; }
                .card-header .stats p { margin: 0; }
                table { width: 100%; border-collapse: collapse; }
                th, td { padding: 12px 15px; text-align: left; border-bottom: 1px solid #eee; }
                thead { background-color: #e9ecef; }
                th { font-weight: 600; color: #495057; }
                tbody tr:hover { background-color: #f1f3f5; }
                td.incorrect { color: #e53e3e; background-color: #fff5f5; }
                td.result-cell { text-align: center; }
                .correct-icon { color: #38a169; font-weight: bold; }
                .incorrect-icon { color: #e53e3e; font-weight: bold; }
                em { color: #999; font-style: italic; }
                @media (prefers-color-scheme: dark) {
                  body { background-color: #111827; color: #e5e7eb; }
                  .container { background-color: #1f2937; box-shadow: 0 4px 12px rgba(0,0,0,0.4); }
                  .summary { border-color: #374151; }
                  .summary-item { background-color: #374151; }
                  .summary-item .label { color: #9ca3af; }
                  .summary-item .value { color: #67e8f9; }
                  .content { border-color: #374151; }
                  .card { border-color: #4b5563; }
                  .card-header { background-color: #374151; border-color: #4b5563; }
                  table { border-color: #4b5563; }
                  th, td { border-color: #4b5563; }
                  thead { background-color: #4b5563; }
                  th { color: #d1d5db; }
                  tbody tr:hover { background-color: #374151; }
                  td.incorrect { color: #f87171; background-color: #4c1d1d; }
                  em { color: #6b7280; }
                }
            </style>
        </head>
        <body>
            <div class="container">
                <header>
                    <h1>Training Results</h1>
                    <p>User: ${username}</p>
                </header>
                <div class="summary">
                    <div class="summary-item">
                        <div class="label">Attempt #</div>
                        <div class="value">${attemptNumber}</div>
                    </div>
                     <div class="summary-item">
                        <div class="label">Total Time</div>
                        <div class="value">${formatTime(totalTime)}</div>
                    </div>
                    <div class="summary-item">
                        <div class="label">Accuracy</div>
                        <div class="value">${accuracy}%</div>
                    </div>
                    <div class="summary-item">
                        <div class="label">Score</div>
                        <div class="value">${correctItems} / ${totalItems}</div>
                    </div>
                </div>
                <div class="content">
                    ${resultsHtml}
                </div>
            </div>
        </body>
        </html>
    `;
};

const generateCSVData = (username: string, results: UserResult[], trainingData: TrainingImage[]) => {
    const headers = [
        'Username',
        'Image ID',
        'Image Time Taken (s)',
        'Prompt',
        'User Input',
        'Correct Answer',
        'Is Correct'
    ];
    
    const escapeCSV = (field: string | number | boolean | null | undefined) => {
        if (field === null || field === undefined) return '';
        const str = String(field);
        if (str.includes(',') || str.includes('"') || str.includes('\n')) {
            return `"${str.replace(/"/g, '""')}"`;
        }
        return str;
    };

    const rows = results.flatMap(result => {
        const originalImage = trainingData.find(img => img.id === result.imageId);
        return result.items.map(item => [
            username,
            result.imageId,
            result.timeTaken,
            item.prompt,
            item.userInput,
            originalImage?.items.find(i => i.prompt === item.prompt)?.correctAnswer || '',
            item.isCorrect
        ].map(escapeCSV).join(','));
    });

    return [headers.join(','), ...rows].join('\n');
};


const ResultsScreen: React.FC<ResultsScreenProps> = ({ username, results, trainingData, onRestart, userAttempts }) => {
  const totalItems = results.reduce((sum, result) => sum + result.items.length, 0);
  const correctItems = results.reduce((sum, result) => sum + result.items.filter(item => item.isCorrect).length, 0);
  const totalTime = results.reduce((sum, result) => sum + result.timeTaken, 0);
  const accuracy = totalItems > 0 ? ((correctItems / totalItems) * 100).toFixed(1) : '0.0';
  const attemptNumber = userAttempts.length;
  
  const handleExportHTML = () => {
    const htmlContent = generateHTMLReport(username, results, trainingData, attemptNumber);
    const date = new Date().toISOString().slice(0, 10);
    const filename = `Training-Results-${username}-${date}.html`;
    downloadFile(htmlContent, filename, 'text/html');
  };
  
  const handleExportCSV = () => {
    const csvContent = generateCSVData(username, results, trainingData);
    const date = new Date().toISOString().slice(0, 10);
    const filename = `Training-Data-${username}-${date}.csv`;
    downloadFile(csvContent, filename, 'text/csv');
  };


  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-white dark:bg-gray-800 p-8 rounded-lg shadow-2xl mb-8">
        <h2 className="text-3xl font-bold text-center text-cyan-500 dark:text-cyan-400 mb-2">Training Complete</h2>
        <p className="text-center text-gray-500 dark:text-gray-400 mb-6">Results for: {username}</p>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
          <div className="bg-gray-100 dark:bg-gray-700 p-4 rounded-lg">
            <div className="text-sm text-gray-500 dark:text-gray-400">Attempt #</div>
            <div className="text-2xl font-bold text-gray-900 dark:text-white">{attemptNumber}</div>
          </div>
          <div className="bg-gray-100 dark:bg-gray-700 p-4 rounded-lg">
            <div className="text-sm text-gray-500 dark:text-gray-400">Total Time</div>
            <div className="text-2xl font-bold text-gray-900 dark:text-white">{formatTime(totalTime)}</div>
          </div>
          <div className="bg-gray-100 dark:bg-gray-700 p-4 rounded-lg">
            <div className="text-sm text-gray-500 dark:text-gray-400">Accuracy</div>
            <div className="text-2xl font-bold text-green-600 dark:text-green-400">{accuracy}%</div>
          </div>
          <div className="bg-gray-100 dark:bg-gray-700 p-4 rounded-lg">
            <div className="text-sm text-gray-500 dark:text-gray-400">Score</div>
            <div className="text-2xl font-bold text-gray-900 dark:text-white">{correctItems} / {totalItems}</div>
          </div>
        </div>
      </div>

      <div className="space-y-6">
        {results.map((result, index) => {
          const originalImage = trainingData.find(img => img.id === result.imageId);
          const correctInImage = result.items.filter(i => i.isCorrect).length;
          const totalInImage = result.items.length;

          return (
            <div key={result.imageId} className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-lg">
              <div className="flex justify-between items-center mb-4">
                  <div>
                    <h3 className="text-xl font-bold text-gray-900 dark:text-white">Image {index + 1} Review</h3>
                    {originalImage && <a href={originalImage.imageUrl} target="_blank" rel="noopener noreferrer" className="text-xs text-cyan-500 dark:text-cyan-400 hover:underline">View Image</a>}
                  </div>
                  <div className="text-right">
                    <p className="font-semibold text-gray-900 dark:text-white">{correctInImage} / {totalInImage} Correct</p>
                    <p className="text-sm text-gray-500 dark:text-gray-400">Time: {formatTime(result.timeTaken)}</p>
                  </div>
              </div>
              
              <div className="overflow-x-auto">
                <table className="w-full text-sm text-left">
                  <thead className="text-xs text-gray-500 dark:text-gray-400 uppercase bg-gray-100 dark:bg-gray-700">
                    <tr>
                      <th scope="col" className="px-4 py-3 w-1/4">Prompt Value</th>
                      <th scope="col" className="px-4 py-3 w-2/5">Your Input</th>
                      <th scope="col" className="px-4 py-3 w-2/5">Correct Answer</th>
                      <th scope="col" className="px-4 py-3 text-center">Result</th>
                    </tr>
                  </thead>
                  <tbody>
                    {result.items.map((item, itemIndex) => {
                      const correctAnswer = originalImage?.items.find(i => i.prompt === item.prompt)?.correctAnswer;
                      return (
                        <tr key={itemIndex} className="border-b border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600/50">
                          <td className="px-4 py-3 font-medium text-gray-800 dark:text-gray-200">{item.prompt}</td>
                          <td className={`px-4 py-3 ${!item.isCorrect ? 'text-red-600 dark:text-red-400' : ''}`}>{item.userInput || <span className="text-gray-400 dark:text-gray-500 italic">No input</span>}</td>
                          <td className="px-4 py-3 text-green-600 dark:text-green-400">{correctAnswer}</td>
                          <td className="px-4 py-3 text-center">
                            {item.isCorrect ? <span className="inline-block text-green-500 dark:text-green-400"><CheckIcon /></span> : <span className="inline-block text-red-500 dark:text-red-400"><XIcon /></span>}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          );
        })}
      </div>
      <div className="mt-8 flex justify-center items-center gap-4 flex-wrap">
        <button
          onClick={onRestart}
          className="bg-cyan-600 hover:bg-cyan-700 text-white font-bold py-3 px-8 rounded-md transition-colors"
        >
          Back to Dashboard
        </button>
        <button
          onClick={handleExportHTML}
          className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3 px-6 rounded-md transition-colors flex items-center gap-2"
          aria-label="Export results as a printable HTML report"
        >
          <DownloadIcon /> Export Report (HTML)
        </button>
        <button
          onClick={handleExportCSV}
          className="bg-gray-600 hover:bg-gray-700 dark:bg-gray-600 dark:hover:bg-gray-500 text-white font-bold py-3 px-6 rounded-md transition-colors flex items-center gap-2"
          aria-label="Export results data as a CSV file for spreadsheets"
        >
          <DownloadIcon /> Export Data (CSV)
        </button>
      </div>
    </div>
  );
};

export default ResultsScreen;